if nEventID == 1 then
	if pUser:CheckClass(111, 112, -1, -1, -1, -1) then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	pUser:SelectMsg(1, 3, 8, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	pUser:SelectMsg(1, 3, 8, 4, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	pUser:SelectMsg(1, 3, 8, 4, 9, 5, 10, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	pUser:SelectMsg(1, 3, 8, 4, 9, 5, 10, 6, 11, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	pUser:SelectMsg(1, 3, 8, 4, 9, 5, 10, 6, 11, 7, 12, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 8 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	pUser:NpcSay(3, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(389010000, 10) then
	if pUser:CheckExistItem(379001000, 10) then
	pUser:RobItem(389010000, 10);
	pUser:RobItem(379001000, 10);
	pUser:NpcSay(2, -1, -1, -1, -1, -1, -1, -1);
	pUser:GiveItem(389011000, 10);
	do return; end
	end
	end
elseif nEventID == 9 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	pUser:NpcSay(3, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	if pUser:CheckExistItem(389010000, 10) then
	if pUser:CheckExistItem(379002000, 10) then
	pUser:RobItem(389010000, 10);
	pUser:RobItem(379002000, 10);
	pUser:NpcSay(2, -1, -1, -1, -1, -1, -1, -1);
	pUser:GiveItem(389012000, 10);
	do return; end
	end
	end
	end
elseif nEventID == 10 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	pUser:NpcSay(3, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	if pUser:CheckExistItem(389010000, 10) then
	if pUser:CheckExistItem(379003000, 10) then
	pUser:RobItem(389010000, 10);
	pUser:RobItem(379003000, 10);
	pUser:NpcSay(2, -1, -1, -1, -1, -1, -1, -1);
	pUser:GiveItem(389013000, 10);
	do return; end
	end
	end
	end
elseif nEventID == 11 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	pUser:NpcSay(3, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	if pUser:CheckExistItem(389010000, 10) then
	if pUser:CheckExistItem(379004000, 10) then
	pUser:RobItem(389010000, 10);
	pUser:RobItem(379004000, 10);
	pUser:NpcSay(2, -1, -1, -1, -1, -1, -1, -1);
	pUser:GiveItem(389014000, 10);
	do return; end
	end
	end
	end
elseif nEventID == 12 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	pUser:NpcSay(3, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_POINT'.");
	if false then -- unknown logic command (CHECK_SKILL_POINT)
	if pUser:CheckExistItem(389010000, 10) then
	if pUser:CheckExistItem(379005000, 10) then
	pUser:RobItem(389010000, 10);
	pUser:RobItem(379005000, 10);
	pUser:NpcSay(2, -1, -1, -1, -1, -1, -1, -1);
	pUser:GiveItem(389015000, 10);
	do return; end
	end
	end
	end
elseif nEventID == 1001 then
	pUser:SelectMsg(15952, 1001, 2001, 1002, 16951, 1006, 2101, 35578, 35623, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 2001 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_KNIGHT'.");
	if false then -- unknown logic command (CHECK_KNIGHT)
	pUser:NpcSay(1059, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_CHIEF'.");
	if false then -- unknown logic command (CHECK_CHIEF)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_CLAN_GRADE'.");
	if false then -- unknown logic command (CHECK_CLAN_GRADE)
	pUser:NpcSay(1055, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_CLAN_GRADE'.");
	if false then -- unknown logic command (CHECK_CLAN_GRADE)
	pUser:SelectMsg(1051, 601, 2045, 603, 2056, 602, 2050, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NO_CHIEF'.");
	if false then -- unknown logic command (CHECK_NO_CHIEF)
	pUser:NpcSay(1050, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 2045 then
	pUser:NpcSay(1052, 1053, 1054, -1, -1, -1, -1, -1);
elseif nEventID == 2050 then
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 9999999 then
	pUser:NpcSay(1057, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910045000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(1058, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(10000000);
	pUser:RobItem(910045000, 1);
	pUser:SendDebugString("Unknown EXEC command 'PROMOTE_KNIGHT'."); -- unknown execute command (PROMOTE_KNIGHT)
	do return; end
	pUser:NpcSay(1062, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 2056 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_CLAN_GRADE'.");
	if false then -- unknown logic command (CHECK_CLAN_GRADE)
	pUser:SendDebugString("Unknown EXEC command 'ZONE_CHANGE_CLAN'."); -- unknown execute command (ZONE_CHANGE_CLAN)
	do return; end
	do return; end
	end
elseif nEventID == 2101 then
	pUser:SendDebugString("Unknown EXEC command 'REQUEST_REWARD'."); -- unknown execute command (REQUEST_REWARD)
	do return; end
elseif nEventID == 3001 then
	do return; end
elseif nEventID == 3002 then
	do return; end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_EDITBOX'.");
	if false then -- unknown logic command (CHECK_EDITBOX)
	do return; end
	pUser:NpcSay(3002, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	do return; end
	do return; end
	pUser:GoldLose(10000);
	pUser:SendDebugString("Unknown EXEC command 'LOG_COUPON_ITEM'."); -- unknown execute command (LOG_COUPON_ITEM)
	do return; end
	pUser:NpcSay(3003, -1, -1, -1, -1, -1, -1, -1);
	if pUser:CheckClass(1, -1, -1, -1, -1, -1) then
	pUser:SendDebugString("Unknown LOGIC command 'RAND'.");
	if false then -- unknown logic command (RAND)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	do return; end
	pUser:GiveItem(120110163, 1);
	pUser:SendDebugString("Unknown EXEC command 'LOG_COUPON_ITEM'."); -- unknown execute command (LOG_COUPON_ITEM)
	do return; end
	pUser:NpcSay(3004, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckClass(2, -1, -1, -1, -1, -1) then
	pUser:SendDebugString("Unknown LOGIC command 'RAND'.");
	if false then -- unknown logic command (RAND)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	do return; end
	pUser:GiveItem(160100163, 1);
	pUser:SendDebugString("Unknown EXEC command 'LOG_COUPON_ITEM'."); -- unknown execute command (LOG_COUPON_ITEM)
	do return; end
	pUser:NpcSay(3005, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckClass(3, -1, -1, -1, -1, -1) then
	pUser:SendDebugString("Unknown LOGIC command 'RAND'.");
	if false then -- unknown logic command (RAND)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	do return; end
	pUser:GiveItem(180110163, 1);
	pUser:SendDebugString("Unknown EXEC command 'LOG_COUPON_ITEM'."); -- unknown execute command (LOG_COUPON_ITEM)
	do return; end
	pUser:NpcSay(3006, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckClass(4, -1, -1, -1, -1, -1) then
	pUser:SendDebugString("Unknown LOGIC command 'RAND'.");
	if false then -- unknown logic command (RAND)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_WEIGHT'.");
	if false then -- unknown logic command (CHECK_WEIGHT)
	do return; end
	pUser:GiveItem(190210163, 1);
	pUser:SendDebugString("Unknown EXEC command 'LOG_COUPON_ITEM'."); -- unknown execute command (LOG_COUPON_ITEM)
	do return; end
	pUser:NpcSay(3007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
elseif nEventID == 6010 then
	pUser:SendDebugString("Unhandled LOGIC command 'CHECK_PROMOTION_ELIGIBLE'."); -- unhandled logic command (CHECK_PROMOTION_ELIGIBLE)
	if false then
	pUser:SelectMsg(6000, 501, 6030, 502, 6040, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 6011 then
	pUser:SendDebugString("Unhandled LOGIC command 'CHECK_PROMOTION_ELIGIBLE'."); -- unhandled logic command (CHECK_PROMOTION_ELIGIBLE)
	if false then
	pUser:SelectMsg(7000, 501, 6030, 502, 6040, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 6013 then
	pUser:SendDebugString("Unhandled LOGIC command 'CHECK_PROMOTION_ELIGIBLE'."); -- unhandled logic command (CHECK_PROMOTION_ELIGIBLE)
	if false then
	pUser:SelectMsg(8000, 501, 6030, 502, 6040, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 6030 then
	pUser:SendDebugString("Unknown EXEC command 'GIVE_PROMOTION_QUEST'."); -- unknown execute command (GIVE_PROMOTION_QUEST)
	do return; end
elseif nEventID == 6040 then
	pUser:SendDebugString("Unknown EXEC command 'PROMOTE_USER'."); -- unknown execute command (PROMOTE_USER)
	do return; end
	do return; end
elseif nEventID == 7281 then
	local count = pUser:HowMuchItem(379049000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(7160, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 7282 then
	local count = pUser:HowMuchItem(379050000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(7160, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 7283 then
	local count = pUser:HowMuchItem(379051000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(7160, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 7284 then
	local count = pUser:HowMuchItem(379052000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(7160, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 7285 then
	local count = pUser:HowMuchItem(379053000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(7160, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 7291 then
	local count = pUser:HowMuchItem(379049000);
	if count >= 1 and count <= 9999 then
	if pUser:CheckExistItem(379049000, 5) then
	if pUser:CheckClass(1, -1, -1, -1, -1, -1) then
	pUser:GoldLose(100000);
	RunCountExchange(sUID, 7110, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379049000, 5) then
	if pUser:CheckClass(2, -1, -1, -1, -1, -1) then
	pUser:GoldLose(100000);
	RunCountExchange(sUID, 7120, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379049000, 5) then
	if pUser:CheckClass(3, -1, -1, -1, -1, -1) then
	pUser:GoldLose(100000);
	RunCountExchange(sUID, 7130, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379049000, 5) then
	if pUser:CheckClass(4, -1, -1, -1, -1, -1) then
	pUser:GoldLose(100000);
	RunCountExchange(sUID, 7140, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
elseif nEventID == 7292 then
	local count = pUser:HowMuchItem(379050000);
	if count >= 1 and count <= 9999 then
	if pUser:CheckExistItem(379050000, 5) then
	if pUser:CheckClass(1, -1, -1, -1, -1, -1) then
	pUser:GoldLose(80000);
	RunCountExchange(sUID, 7150, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379050000, 5) then
	if pUser:CheckClass(2, -1, -1, -1, -1, -1) then
	pUser:GoldLose(80000);
	RunCountExchange(sUID, 7160, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379050000, 5) then
	if pUser:CheckClass(3, -1, -1, -1, -1, -1) then
	pUser:GoldLose(80000);
	RunCountExchange(sUID, 7170, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379050000, 5) then
	if pUser:CheckClass(4, -1, -1, -1, -1, -1) then
	pUser:GoldLose(80000);
	RunCountExchange(sUID, 7180, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
elseif nEventID == 7293 then
	local count = pUser:HowMuchItem(379051000);
	if count >= 1 and count <= 9999 then
	if pUser:CheckExistItem(379051000, 5) then
	if pUser:CheckClass(1, -1, -1, -1, -1, -1) then
	pUser:GoldLose(50000);
	RunCountExchange(sUID, 7190, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379051000, 5) then
	if pUser:CheckClass(2, -1, -1, -1, -1, -1) then
	pUser:GoldLose(50000);
	RunCountExchange(sUID, 7200, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379051000, 5) then
	if pUser:CheckClass(3, -1, -1, -1, -1, -1) then
	pUser:GoldLose(50000);
	RunCountExchange(sUID, 7210, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379051000, 5) then
	if pUser:CheckClass(4, -1, -1, -1, -1, -1) then
	pUser:GoldLose(50000);
	RunCountExchange(sUID, 7220, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
elseif nEventID == 7294 then
	local count = pUser:HowMuchItem(379052000);
	if count >= 1 and count <= 9999 then
	if pUser:CheckExistItem(379052000, 5) then
	if pUser:CheckClass(1, -1, -1, -1, -1, -1) then
	pUser:GoldLose(40000);
	RunCountExchange(sUID, 7230, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379052000, 5) then
	if pUser:CheckClass(2, -1, -1, -1, -1, -1) then
	pUser:GoldLose(40000);
	RunCountExchange(sUID, 7240, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379052000, 5) then
	if pUser:CheckClass(3, -1, -1, -1, -1, -1) then
	pUser:GoldLose(40000);
	RunCountExchange(sUID, 7250, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379052000, 5) then
	if pUser:CheckClass(4, -1, -1, -1, -1, -1) then
	pUser:GoldLose(40000);
	RunCountExchange(sUID, 7260, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
elseif nEventID == 7295 then
	local count = pUser:HowMuchItem(379053000);
	if count >= 1 and count <= 9999 then
	if pUser:CheckExistItem(379053000, 5) then
	if pUser:CheckClass(1, -1, -1, -1, -1, -1) then
	pUser:GoldLose(30000);
	RunCountExchange(sUID, 7270, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379053000, 5) then
	if pUser:CheckClass(2, -1, -1, -1, -1, -1) then
	pUser:GoldLose(30000);
	RunCountExchange(sUID, 7280, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379053000, 5) then
	if pUser:CheckClass(3, -1, -1, -1, -1, -1) then
	pUser:GoldLose(30000);
	RunCountExchange(sUID, 7290, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	if pUser:CheckExistItem(379053000, 5) then
	if pUser:CheckClass(4, -1, -1, -1, -1, -1) then
	pUser:GoldLose(30000);
	RunCountExchange(sUID, 7300, 0);
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7320, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7330, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7340, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_ITEMCHANGE_NUM'.");
	if false then -- unknown logic command (CHECK_ITEMCHANGE_NUM)
	pUser:NpcSay(7350, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
elseif nEventID == 8001 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOEXIST_ITEM'.");
	if false then -- unknown logic command (CHECK_NOEXIST_ITEM)
	pUser:NpcSay(10310, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(910014000, 5) then
	RunCountExchange(sUID, 5, 0);
	do return; end
	end
elseif nEventID == 9001 then
	pUser:SelectMsg(10410, 801, 8001, 802, 9005, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 9005 then
	local state = pUser:SearchQuest(6);
	if state == 1 then
	local lvl = pUser:GetLevel();
	if lvl >= 30 and lvl <= 99 then
	pUser:NpcSay(10240, -1, -1, -1, -1, -1, -1, -1);
	pUser:GiveItem(910013000, 1);
	pUser:SaveEvent(6, 2);
	do return; end
	end
	end
	local state = pUser:SearchQuest(6);
	if state == 1 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 29 then
	pUser:NpcSay(10230, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 11 and lvl <= 99 then
	pUser:NpcSay(10210, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(6);
	if state == 0 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 11 then
	pUser:NpcSay(10220, -1, -1, -1, -1, -1, -1, -1);
	pUser:SaveEvent(6, 1);
	do return; end
	end
	end
elseif nEventID == 10000 then
	pUser:SelectMsg(10000, 601, 10001, 602, 10013, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 10001 then
	pUser:NpcSay(10001, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 10003 then
	local count = pUser:HowMuchItem(379063000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 10004 then
	local count = pUser:HowMuchItem(379041000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389076000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910042000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379099000);
	if count >= 0 and count <= 19 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379204000);
	if count >= 0 and count <= 49 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379067000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379063000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(51);
	if state == 1 then
	if pUser:CheckExistItem(379041000, 1) then
	if pUser:CheckExistItem(389076000, 30) then
	if pUser:CheckExistItem(910042000, 30) then
	if pUser:CheckExistItem(379099000, 20) then
	if pUser:CheckExistItem(379204000, 50) then
	if pUser:CheckExistItem(379067000, 1) then
	if pUser:CheckExistItem(379063000, 1) then
	pUser:RobItem(379041000, 1);
	pUser:RobItem(389076000, 30);
	pUser:RobItem(910042000, 30);
	pUser:RobItem(379099000, 20);
	pUser:RobItem(379204000, 50);
	pUser:RobItem(379067000, 1);
	pUser:RobItem(379063000, 1);
	pUser:SaveEvent(51, 2);
	pUser:NpcSay(10006, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
	end
	end
	end
	end
elseif nEventID == 10013 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 69 then
	pUser:NpcSay(10014, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 70 and lvl <= 99 then
	local state = pUser:SearchQuest(51);
	if state == 2 then
	pUser:NpcSay(10017, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379041000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389076000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910042000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379099000);
	if count >= 0 and count <= 19 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379204000);
	if count >= 0 and count <= 49 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379067000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379063000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10007, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(51);
	if state == 1 then
	if pUser:CheckExistItem(379041000, 1) then
	if pUser:CheckExistItem(389076000, 30) then
	if pUser:CheckExistItem(910042000, 30) then
	if pUser:CheckExistItem(379099000, 20) then
	if pUser:CheckExistItem(379204000, 50) then
	if pUser:CheckExistItem(379067000, 1) then
	if pUser:CheckExistItem(379063000, 1) then
	pUser:RobItem(379041000, 1);
	pUser:RobItem(389076000, 30);
	pUser:RobItem(910042000, 30);
	pUser:RobItem(379099000, 20);
	pUser:RobItem(379204000, 50);
	pUser:RobItem(379067000, 1);
	pUser:RobItem(379063000, 1);
	pUser:SaveEvent(51, 2);
	pUser:NpcSay(10006, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
	end
	end
	end
	end
	end
elseif nEventID == 10020 then
	pUser:SelectMsg(10020, 601, 10021, 602, 10022, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 10021 then
	pUser:NpcSay(10021, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 10022 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 69 then
	pUser:NpcSay(10014, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 70 and lvl <= 99 then
	local state = pUser:SearchQuest(52);
	if state == 2 then
	pUser:NpcSay(10017, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379042000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379045000);
	if count >= 0 and count <= 19 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379014000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379113000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379201000);
	if count >= 0 and count <= 49 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379067000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379064000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(52);
	if state == 1 then
	if pUser:CheckExistItem(379042000, 1) then
	if pUser:CheckExistItem(379045000, 20) then
	if pUser:CheckExistItem(379014000, 30) then
	if pUser:CheckExistItem(379113000, 5) then
	if pUser:CheckExistItem(379201000, 50) then
	if pUser:CheckExistItem(379067000, 1) then
	if pUser:CheckExistItem(379064000, 1) then
	pUser:RobItem(379042000, 1);
	pUser:RobItem(379045000, 20);
	pUser:RobItem(379014000, 30);
	pUser:RobItem(379113000, 5);
	pUser:RobItem(379201000, 50);
	pUser:RobItem(379067000, 1);
	pUser:RobItem(379064000, 1);
	pUser:SaveEvent(52, 2);
	pUser:NpcSay(10031, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
	end
	end
	end
	end
	end
elseif nEventID == 10040 then
	pUser:SelectMsg(10040, 601, 10041, 602, 10042, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 10041 then
	pUser:NpcSay(10041, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 10042 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 69 then
	pUser:NpcSay(10014, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 70 and lvl <= 99 then
	local state = pUser:SearchQuest(53);
	if state == 2 then
	pUser:NpcSay(10017, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379040000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389074000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379011000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379098000);
	if count >= 0 and count <= 19 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379203000);
	if count >= 0 and count <= 49 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379067000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379065000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(53);
	if state == 1 then
	if pUser:CheckExistItem(379040000, 1) then
	if pUser:CheckExistItem(389074000, 30) then
	if pUser:CheckExistItem(379011000, 30) then
	if pUser:CheckExistItem(379098000, 20) then
	if pUser:CheckExistItem(379203000, 50) then
	if pUser:CheckExistItem(379067000, 1) then
	if pUser:CheckExistItem(379065000, 1) then
	pUser:RobItem(379040000, 1);
	pUser:RobItem(389074000, 30);
	pUser:RobItem(379011000, 30);
	pUser:RobItem(379098000, 20);
	pUser:RobItem(379203000, 50);
	pUser:RobItem(379067000, 1);
	pUser:RobItem(379065000, 1);
	pUser:SaveEvent(53, 2);
	pUser:NpcSay(10051, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
	end
	end
	end
	end
	end
elseif nEventID == 10060 then
	pUser:SelectMsg(10060, 601, 10061, 602, 10062, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 10061 then
	pUser:NpcSay(10061, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 10062 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 69 then
	pUser:NpcSay(10014, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 70 and lvl <= 99 then
	local state = pUser:SearchQuest(54);
	if state == 2 then
	pUser:NpcSay(10017, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379046000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389075000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379044000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379112000);
	if count >= 0 and count <= 1 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379202000);
	if count >= 0 and count <= 49 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379067000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379066000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(10072, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(54);
	if state == 1 then
	if pUser:CheckExistItem(379046000, 1) then
	if pUser:CheckExistItem(389075000, 30) then
	if pUser:CheckExistItem(379044000, 30) then
	if pUser:CheckExistItem(379112000, 2) then
	if pUser:CheckExistItem(379202000, 50) then
	if pUser:CheckExistItem(379067000, 1) then
	if pUser:CheckExistItem(379066000, 1) then
	pUser:RobItem(379046000, 1);
	pUser:RobItem(389075000, 30);
	pUser:RobItem(379044000, 30);
	pUser:RobItem(379112000, 2);
	pUser:RobItem(379202000, 50);
	pUser:RobItem(379067000, 1);
	pUser:RobItem(379066000, 1);
	pUser:SaveEvent(54, 2);
	pUser:NpcSay(10071, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	end
	end
	end
	end
	end
	end
elseif nEventID == 10587 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 49 then
	pUser:NpcSay(15087, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 11001 then
	if pUser:CheckClass(101, 105, 106, -1, -1, -1) then
	pUser:SelectMsg(11008, 11001, 6010, 10000, 11050, 17010, 17027, 17070, 17070, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SelectMsg(17073, 17070, 17070, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 11010 then
	if pUser:CheckClass(106, -1, -1, -1, -1, -1) then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 61 then
	pUser:NpcSay(11120, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379063000, 1) then
	pUser:NpcSay(11130, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 4999999 then
	pUser:NpcSay(11140, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379046000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(11150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389074000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(11150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(5000000);
	RunCountExchange(sUID, 11101, 0);
	pUser:NpcSay(11170, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	do return; end
	end
	if pUser:CheckClass(101, 105, -1, -1, -1, -1) then
	pUser:NpcSay(11030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 11050 then
	pUser:SelectMsg(11010, 11101, 11101, 10001, 10000, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 11101 then
	pUser:SelectMsg(11101, 601, 11105, 602, 11010, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 11105 then
	pUser:NpcSay(11105, 11106, 11107, 11108, -1, -1, -1, -1);
	do return; end
elseif nEventID == 12001 then
	if pUser:CheckClass(107, 108, 102, -1, -1, -1) then
	pUser:SelectMsg(12008, 11001, 6011, 10000, 12050, 17010, 17040, 17070, 17080, 17501, 17500, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SelectMsg(17083, 17070, 17080, 17501, 17500, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 12010 then
	if pUser:CheckClass(108, -1, -1, -1, -1, -1) then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 61 then
	pUser:NpcSay(12120, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379064000, 1) then
	pUser:NpcSay(12130, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 4999999 then
	pUser:NpcSay(12140, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(330310014);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(12150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389075000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(12150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(5000000);
	RunCountExchange(sUID, 12101, 0);
	pUser:NpcSay(12170, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	do return; end
	end
	if pUser:CheckClass(102, 107, -1, -1, -1, -1) then
	pUser:NpcSay(12030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 12050 then
	pUser:SelectMsg(12010, 12101, 12101, 10001, 10020, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 12101 then
	pUser:SelectMsg(12101, 601, 12105, 602, 12010, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 12105 then
	pUser:NpcSay(12105, 12106, 12107, 12108, -1, -1, -1, -1);
	do return; end
elseif nEventID == 13001 then
	if pUser:CheckClass(109, 110, 103, -1, -1, -1) then
	pUser:SelectMsg(13008, 11001, 6013, 10000, 13050, 17010, 17050, 17070, 17090, 17640, 17640, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SelectMsg(17093, 17070, 17090, 17640, 17640, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 13010 then
	if pUser:CheckClass(110, -1, -1, -1, -1, -1) then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 61 then
	pUser:NpcSay(13120, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379065000, 1) then
	pUser:NpcSay(13130, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 4999999 then
	pUser:NpcSay(13140, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379022000);
	if count >= 0 and count <= 2 then
	pUser:NpcSay(13150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379030000);
	if count >= 0 and count <= 2 then
	pUser:NpcSay(13150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379031000);
	if count >= 0 and count <= 2 then
	pUser:NpcSay(13150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379032000);
	if count >= 0 and count <= 2 then
	pUser:NpcSay(13150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379033000);
	if count >= 0 and count <= 2 then
	pUser:NpcSay(13150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(5000000);
	RunCountExchange(sUID, 13101, 0);
	pUser:NpcSay(13170, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	do return; end
	end
	if pUser:CheckClass(103, 109, -1, -1, -1, -1) then
	pUser:NpcSay(13030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 13050 then
	pUser:SelectMsg(13010, 13801, 13801, 13831, 13831, 13101, 13101, 10001, 10040, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 13101 then
	pUser:SelectMsg(13101, 601, 13105, 602, 13010, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 13105 then
	pUser:NpcSay(13105, 13106, 13107, 13108, -1, -1, -1, -1);
	do return; end
elseif nEventID == 13801 then
	pUser:SelectMsg(13801, 601, 13803, 602, 13805, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 13803 then
	pUser:NpcSay(13803, 13804, 13805, 13806, -1, -1, -1, -1);
	do return; end
elseif nEventID == 13805 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 53 then
	pUser:NpcSay(13811, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379069000, 1) then
	pUser:NpcSay(13813, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 4999999 then
	pUser:NpcSay(13815, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389074000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(13817, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389075000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(13817, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389076000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(13817, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(5000000);
	RunCountExchange(sUID, 13801, 0);
	pUser:NpcSay(13830, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	do return; end
elseif nEventID == 13831 then
	pUser:SelectMsg(13831, 601, 13833, 602, 13835, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 13833 then
	pUser:NpcSay(13833, 13834, 13835, 13836, -1, -1, -1, -1);
	do return; end
elseif nEventID == 13835 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 56 then
	pUser:NpcSay(13841, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379070000, 1) then
	pUser:NpcSay(13843, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 4999999 then
	pUser:NpcSay(13845, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(263001271);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(13847, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(263002271);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(13847, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(263003271);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(13847, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(263004271);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(13847, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(263005271);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(13847, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(5000000);
	RunCountExchange(sUID, 13831, 0);
	pUser:NpcSay(13860, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	do return; end
elseif nEventID == 14001 then
	if pUser:CheckClass(111, 112, 104, -1, -1, -1) then
	pUser:SelectMsg(14008, 11001, 6010, 10000, 14050, 17010, 17060, 17070, 17070, 17660, 17660, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SelectMsg(17074, 17070, 17070, 17660, 17660, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 14010 then
	if pUser:CheckClass(112, 212, -1, -1, -1, -1) then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 61 then
	pUser:NpcSay(14120, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379066000, 1) then
	pUser:NpcSay(14130, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 4999999 then
	pUser:NpcSay(14140, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(379044000);
	if count >= 0 and count <= 99 then
	pUser:NpcSay(14150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(389076000);
	if count >= 0 and count <= 29 then
	pUser:NpcSay(14150, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GoldLose(5000000);
	RunCountExchange(sUID, 14101, 0);
	pUser:NpcSay(14170, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	do return; end
	end
	if pUser:CheckClass(104, 111, 204, 211, -1, -1) then
	pUser:NpcSay(14030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 14050 then
	pUser:SelectMsg(14010, 14101, 14101, 10001, 10060, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 14101 then
	pUser:SelectMsg(14101, 601, 14105, 602, 14010, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 14105 then
	pUser:NpcSay(14105, 14106, 14107, 14108, -1, -1, -1, -1);
	do return; end
elseif nEventID == 15001 then
	pUser:SelectMsg(15001, 15051, 15055, 15101, 15101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15050 then
	pUser:SelectMsg(15001, 15051, 15055, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15051 then
	local state = pUser:SearchQuest(8);
	if state == 2 then
	pUser:NpcSay(15052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 29 then
	pUser:NpcSay(15053, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SelectMsg(15055, 15060, 15060, 15070, 15070, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15054 then
	local lvl = pUser:GetLevel();
	if lvl >= 34 and lvl <= 250 then
	pUser:NpcSay(15054, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 15060 then
	local state = pUser:SearchQuest(8);
	if state == 0 then
	pUser:NpcSay(15060, 15061, 15062, 15063, -1, -1, -1, -1);
	pUser:GiveItem(910044000, 0);
	do return; end
	end
elseif nEventID == 15070 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 29 then
	pUser:NpcSay(15053, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910040000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(15078, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910041000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15078, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(8);
	if state == 2 then
	pUser:NpcSay(15052, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(8);
	if state == 0 then
	if pUser:CheckExistItem(910040000, 5) then
	if pUser:CheckExistItem(910041000, 1) then
	pUser:RobItem(910040000, 5);
	pUser:RobItem(910041000, 1);
	pUser:ExpChange(368000);
	pUser:SaveEvent(8, 2);
	pUser:NpcSay(15080, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
elseif nEventID == 15076 then
	local lvl = pUser:GetLevel();
	if lvl >= 34 and lvl <= 250 then
	pUser:NpcSay(15054, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 15082 then
	pUser:SelectMsg(15081, 15083, 15083, 15085, 15085, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15083 then
	pUser:NpcSay(15083, 15084, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15085 then
	local count = pUser:HowMuchItem(910042000);
	if count >= 0 and count <= 9 then
	pUser:NpcSay(15090, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	pUser:NpcSay(15091, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(910042000, 10) then
	pUser:RobItem(910042000, 10);
	pUser:GiveItem(910043000, 1);
	pUser:NpcSay(15092, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15088 then
	local lvl = pUser:GetLevel();
	if lvl >= 54 and lvl <= 250 then
	pUser:NpcSay(15088, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 15101 then
	pUser:SelectMsg(15101, 15105, 15105, 15108, 15108, 15110, 15110, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15105 then
	pUser:NpcSay(15105, 15106, 15107, 15108, -1, -1, -1, -1);
	do return; end
elseif nEventID == 15108 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 49 then
	pUser:NpcSay(15115, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910050000);
	if count >= 1 and count <= 50 then
	pUser:NpcSay(15116, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(9);
	if state == 2 then
	pUser:NpcSay(15118, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(9);
	if state == 1 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOEXIST_ITEM'.");
	if false then -- unknown logic command (CHECK_NOEXIST_ITEM)
	pUser:GiveItem(910050000, 0);
	pUser:NpcSay(15119, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	local state = pUser:SearchQuest(9);
	if state == 0 then
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 99 then
	pUser:GiveItem(910050000, 0);
	pUser:SaveEvent(9, 1);
	pUser:NpcSay(15119, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15110 then
	local lvl = pUser:GetLevel();
	if lvl >= 1 and lvl <= 49 then
	pUser:NpcSay(15115, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(9);
	if state == 2 then
	pUser:NpcSay(15118, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local count = pUser:HowMuchItem(910057000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15120, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910057000, 1) then
	pUser:RobItem(910057000, 1);
	pUser:ExpChange(15218948);
	pUser:SaveEvent(9, 2);
	pUser:NpcSay(15125, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
elseif nEventID == 15801 then
	local count = pUser:HowMuchItem(910050000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15803, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15805, 15810, 15810, 15815, 15815, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15810 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910050000, 0) then
	pUser:RobItem(910050000, 0);
	pUser:GiveItem(910051000, 0);
	pUser:SelectMsg(15810, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15812 then
	pUser:SendDebugString("Unknown EXEC command 'CHANGE_POSITION'."); -- unknown execute command (CHANGE_POSITION)
	do return; end
elseif nEventID == 15815 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910050000, 0) then
	pUser:RobItem(910050000, 0);
	pUser:SaveEvent(9, 0);
	pUser:SelectMsg(15815, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15821 then
	local count = pUser:HowMuchItem(910051000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15823, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15825, 15830, 15830, 15835, 15835, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15830 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910051000, 0) then
	pUser:RobItem(910051000, 0);
	pUser:GiveItem(910052000, 0);
	pUser:SelectMsg(15830, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15835 then
	pUser:RobItem(910051000, 0);
	pUser:SelectMsg(15835, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15841 then
	local count = pUser:HowMuchItem(910052000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15843, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15845, 15850, 15850, 15855, 15855, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15850 then
	if pUser:CheckExistItem(910052000, 0) then
	pUser:RobItem(910052000, 0);
	pUser:SelectMsg(15850, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15855 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910052000, 0) then
	pUser:RobItem(910052000, 0);
	pUser:GiveItem(910053000, 0);
	pUser:SelectMsg(15855, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15861 then
	local count = pUser:HowMuchItem(910053000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15863, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15865, 15870, 15870, 15875, 15875, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15870 then
	pUser:RobItem(910053000, 0);
	pUser:SelectMsg(15870, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15875 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910053000, 0) then
	pUser:RobItem(910053000, 0);
	pUser:GiveItem(910054000, 0);
	pUser:SelectMsg(15875, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15881 then
	local count = pUser:HowMuchItem(910054000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15883, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15885, 15890, 15890, 15895, 15895, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15890 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910054000, 0) then
	pUser:RobItem(910054000, 0);
	pUser:GiveItem(910055000, 0);
	pUser:SelectMsg(15890, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15895 then
	if pUser:CheckExistItem(910054000, 0) then
	pUser:RobItem(910054000, 0);
	pUser:SelectMsg(15895, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15901 then
	local count = pUser:HowMuchItem(910055000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15903, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15905, 15910, 15910, 15915, 15915, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15910 then
	if pUser:CheckExistItem(910055000, 0) then
	pUser:RobItem(910055000, 0);
	pUser:SelectMsg(15910, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15915 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910055000, 0) then
	pUser:RobItem(910055000, 0);
	pUser:GiveItem(910056000, 0);
	pUser:SelectMsg(15915, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15921 then
	local count = pUser:HowMuchItem(910056000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15923, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 50 and lvl <= 250 then
	pUser:SelectMsg(15925, 15930, 15930, 15935, 15935, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 15930 then
	pUser:RobItem(910056000, 0);
	pUser:SelectMsg(15930, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 15935 then
	local state = pUser:SearchQuest(9);
	if state == 1 then
	if pUser:CheckExistItem(910056000, 0) then
	pUser:RobItem(910056000, 0);
	pUser:GiveItem(910057000, 0);
	pUser:SelectMsg(15935, 15811, 15812, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 15951 then
	local count = pUser:HowMuchItem(910044000);
	if count >= 0 and count <= 0 then
	pUser:NpcSay(15953, -1, -1, -1, -1, -1, -1, -1);
	end
	if pUser:CheckExistItem(910044000, 0) then
	local count = pUser:HowMuchItem(910044000);
	if count >= 1 and count <= 5 then
	pUser:RobItem(910044000, 1);
	pUser:GiveItem(910041000, 1);
	pUser:NpcSay(15955, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 16951 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	pUser:NpcSay(15956, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	pUser:SelectMsg(15957, 1003, 16956, 1004, 16957, 1005, 16958, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 16956 then
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 1499999 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	pUser:NpcSay(15961, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	pUser:GoldLose(1500000);
	pUser:SendDebugString("Unknown EXEC command 'CHANGE_LOYALTY'."); -- unknown execute command (CHANGE_LOYALTY)
	do return; end
	pUser:NpcSay(15958, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 16957 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 349999 then
	pUser:NpcSay(15961, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_LOYALTY'.");
	if false then -- unknown logic command (CHECK_LOYALTY)
	pUser:GoldLose(350000);
	pUser:SendDebugString("Unknown EXEC command 'CHANGE_LOYALTY'."); -- unknown execute command (CHANGE_LOYALTY)
	do return; end
	pUser:NpcSay(15960, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 16958 then
	pUser:NpcSay(15959, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17000 then
	pUser:SelectMsg(17000, 17002, 17002, 17010, 17010, 17610, 17610, 17620, 17620, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17002 then
	local state = pUser:SearchQuest(56);
	if state == 1 then
	local state = pUser:SearchQuest(56);
	if state == 1 then
	if pUser:CheckExistItem(910080000, 1) then
	pUser:RobItem(910080000, 1);
	pUser:GoldGain(50000);
	pUser:SaveEvent(56, 2);
	pUser:NpcSay(17003, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17008, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(56);
	if state == 2 then
	pUser:NpcSay(17005, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:NpcSay(17004, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17010 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 14 then
	pUser:NpcSay(35665, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 2 then
	pUser:NpcSay(17030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 1 then
	pUser:NpcSay(17014, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 0 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckClass(101, 105, 106, -1, -1, -1) then
	pUser:SelectMsg(17018, 35663, 17022, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	if pUser:CheckClass(102, 107, 108, -1, -1, -1) then
	pUser:SelectMsg(17019, 35663, 17022, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	if pUser:CheckClass(103, 109, 110, -1, -1, -1) then
	pUser:SelectMsg(17020, 35663, 17022, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	if pUser:CheckClass(104, 111, 112, -1, -1, -1) then
	pUser:SelectMsg(17021, 35663, 17022, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 17022 then
	local state = pUser:SearchQuest(57);
	if state == 0 then
	pUser:GiveItem(910081000, 1);
	pUser:SaveEvent(57, 1);
	pUser:NpcSay(17022, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17023 then
	pUser:NpcSay(35643, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17027 then
	local state = pUser:SearchQuest(57);
	if state == 1 then
	if pUser:CheckExistItem(910081000, 1) then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 1 then
	pUser:RobItem(910081000, 1);
	pUser:GiveItem(125070000, 1);
	pUser:SaveEvent(57, 2);
	pUser:NpcSay(17013, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 2 then
	pUser:NpcSay(17030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 0 then
	pUser:NpcSay(17029, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17040 then
	local state = pUser:SearchQuest(57);
	if state == 1 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOEXIST_ITEM'.");
	if false then -- unknown logic command (CHECK_NOEXIST_ITEM)
	pUser:NpcSay(17032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SelectMsg(17047, 17048, 17048, 17049, 17049, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(57);
	if state == 2 then
	pUser:NpcSay(17030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 0 then
	pUser:NpcSay(17029, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17048 then
	local state = pUser:SearchQuest(57);
	if state == 1 then
	pUser:RobItem(910081000, 1);
	pUser:GiveItem(111470000, 1);
	pUser:SaveEvent(57, 2);
	pUser:NpcSay(17013, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17049 then
	local state = pUser:SearchQuest(57);
	if state == 1 then
	pUser:RobItem(910081000, 1);
	pUser:GiveItem(161470000, 1);
	pUser:SaveEvent(57, 2);
	pUser:NpcSay(17013, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17050 then
	local state = pUser:SearchQuest(57);
	if state == 1 then
	if pUser:CheckExistItem(910081000, 1) then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 1 then
	if pUser:CheckExistItem(910081000, 1) then
	pUser:RobItem(910081000, 1);
	pUser:GiveItem(181480000, 1);
	pUser:SaveEvent(57, 2);
	pUser:NpcSay(17013, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	pUser:NpcSay(17032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 2 then
	pUser:NpcSay(17030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 0 then
	pUser:NpcSay(17029, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17060 then
	local state = pUser:SearchQuest(57);
	if state == 1 then
	if pUser:CheckExistItem(910081000, 1) then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 1 then
	if pUser:CheckExistItem(910081000, 1) then
	pUser:RobItem(910081000, 1);
	pUser:GiveItem(191470000, 1);
	pUser:SaveEvent(57, 2);
	pUser:NpcSay(17013, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	end
	pUser:NpcSay(17032, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 2 then
	pUser:NpcSay(17030, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(57);
	if state == 0 then
	pUser:NpcSay(17029, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17070 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 14 then
	pUser:NpcSay(17700, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 15 and lvl <= 99 then
	local state = pUser:SearchQuest(58);
	if state == 2 then
	pUser:NpcSay(17070, 17072, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	do return; end
	end
elseif nEventID == 17080 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 14 then
	pUser:NpcSay(17700, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 15 and lvl <= 99 then
	local state = pUser:SearchQuest(59);
	if state == 2 then
	pUser:NpcSay(17080, 17082, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	do return; end
	end
elseif nEventID == 17090 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 14 then
	pUser:NpcSay(17700, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 15 and lvl <= 99 then
	local state = pUser:SearchQuest(60);
	if state == 2 then
	pUser:NpcSay(17090, 17092, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	do return; end
	end
elseif nEventID == 17100 then
	pUser:SelectMsg(17100, 17101, 17101, 17102, 17105, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17101 then
	pUser:NpcSay(17101, 17102, 17103, 17104, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17105 then
	pUser:SelectMsg(17106, 17106, 17107, 17107, 17108, 17108, 17109, 17109, 17110, 17110, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, 0);
elseif nEventID == 17106 then
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 99 then
	pUser:NpcSay(7170, 7260, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17107 then
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 99 then
	pUser:NpcSay(7170, 7230, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17108 then
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 99 then
	pUser:NpcSay(7170, 7240, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17109 then
	local coins = pUser:GetCoins();
	if coins >= 0 and coins <= 99 then
	pUser:NpcSay(7170, 7250, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17500 then
	local state = pUser:SearchQuest(62);
	if state == 2 then
	pUser:NpcSay(17500, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(62);
	if state == 1 then
	pUser:SelectMsg(17510, 17505, 17505, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(62);
	if state == 0 then
	pUser:SelectMsg(17513, 17506, 17504, 35664, 35664, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17504 then
	local state = pUser:SearchQuest(62);
	if state == 0 then
	pUser:SaveEvent(62, 1);
	pUser:NpcSay(17514, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17505 then
	local count = pUser:HowMuchItem(910082000);
	if count >= 0 and count <= 4 then
	pUser:NpcSay(17511, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(62);
	if state == 1 then
	if pUser:CheckExistItem(910082000, 5) then
	pUser:RobItem(910082000, 5);
	pUser:SaveEvent(62, 2);
	pUser:NpcSay(17512, -1, -1, -1, -1, -1, -1, -1);
	end
	end
elseif nEventID == 17520 then
	pUser:SelectMsg(17520, 17522, 17522, 17523, 17523, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17522 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 29 then
	pUser:NpcSay(17525, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 51 and lvl <= 99 then
	pUser:NpcSay(17526, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(63);
	if state == 2 then
	pUser:NpcSay(17527, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(63);
	if state == 1 then
	pUser:SelectMsg(17529, 17525, 17532, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(63);
	if state == 0 then
	pUser:SelectMsg(17530, 17524, 17531, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17523 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 39 then
	pUser:NpcSay(17535, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(64);
	if state == 2 then
	pUser:NpcSay(17537, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(64);
	if state == 1 then
	pUser:SelectMsg(17538, 17526, 17540, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(64);
	if state == 0 then
	pUser:SelectMsg(17539, 17527, 17543, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17531 then
	local state = pUser:SearchQuest(63);
	if state == 0 then
	pUser:SaveEvent(63, 1);
	pUser:NpcSay(17531, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17532 then
	local state = pUser:SearchQuest(63);
	if state == 1 then
	if pUser:CheckExistItem(910084000, 1) then
	pUser:RobItem(910084000, 1);
	pUser:ExpChange(100000);
	pUser:SendDebugString("Unknown EXEC command 'CHANGE_LOYALTY'."); -- unknown execute command (CHANGE_LOYALTY)
	do return; end
	pUser:SaveEvent(63, 2);
	pUser:NpcSay(17533, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17534, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17540 then
	local state = pUser:SearchQuest(64);
	if state == 1 then
	if pUser:CheckExistItem(910085000, 1) then
	pUser:RobItem(910085000, 1);
	pUser:ExpChange(300000);
	pUser:SendDebugString("Unknown EXEC command 'CHANGE_LOYALTY'."); -- unknown execute command (CHANGE_LOYALTY)
	do return; end
	pUser:SaveEvent(64, 2);
	pUser:NpcSay(17533, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17542, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17543 then
	local state = pUser:SearchQuest(64);
	if state == 0 then
	pUser:SaveEvent(64, 1);
	pUser:NpcSay(17543, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17550 then
	local state = pUser:SearchQuest(66);
	if state == 2 then
	pUser:NpcSay(17551, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(66);
	if state == 1 then
	pUser:NpcSay(17563, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(65);
	if state == 2 then
	pUser:SelectMsg(17560, 17561, 17561, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(65);
	if state == 1 then
	pUser:SelectMsg(17553, 17555, 17555, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(65);
	if state == 0 then
	pUser:SelectMsg(17550, 17558, 17558, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17555 then
	local state = pUser:SearchQuest(65);
	if state == 1 then
	if pUser:CheckExistItem(379204000, 5) then
	pUser:RobItem(379204000, 5);
	pUser:SaveEvent(65, 2);
	pUser:ExpChange(5000);
	pUser:NpcSay(17556, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17557, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17558 then
	pUser:SaveEvent(65, 1);
	pUser:NpcSay(17557, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17561 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:GiveItem(910086000, 1);
	pUser:SaveEvent(66, 1);
	pUser:NpcSay(17561, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17570 then
	local state = pUser:SearchQuest(67);
	if state == 2 then
	pUser:NpcSay(17571, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(67);
	if state == 1 then
	pUser:NpcSay(17572, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(66);
	if state == 2 then
	pUser:SelectMsg(17573, 17576, 17576, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(66);
	if state == 1 then
	pUser:SelectMsg(17574, 17579, 17579, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(66);
	if state == 0 then
	pUser:NpcSay(17575, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17576 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(67);
	if state == 0 then
	pUser:GiveItem(910087000, 1);
	pUser:SaveEvent(67, 1);
	pUser:NpcSay(17572, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17579 then
	local state = pUser:SearchQuest(66);
	if state == 1 then
	if pUser:CheckExistItem(910086000, 1) then
	pUser:RobItem(910086000, 1);
	pUser:SaveEvent(66, 2);
	pUser:ExpChange(5000);
	pUser:NpcSay(17580, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17581, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17590 then
	local state = pUser:SearchQuest(67);
	if state == 2 then
	pUser:NpcSay(17591, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(67);
	if state == 1 then
	pUser:SelectMsg(17592, 17596, 17596, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(67);
	if state == 0 then
	pUser:NpcSay(17595, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17596 then
	local state = pUser:SearchQuest(67);
	if state == 1 then
	if pUser:CheckExistItem(910087000, 1) then
	pUser:RobItem(910087000, 1);
	pUser:SaveEvent(67, 2);
	pUser:GoldGain(500000);
	pUser:NpcSay(17597, -1, -1, -1, -1, -1, -1, -1);
	end
	end
	pUser:NpcSay(17598, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17600 then
	pUser:SelectMsg(17600, 17555, 17601, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17601 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(379204000, 1) then
	pUser:RobItem(379204000, 1);
	pUser:GoldGain(1000);
	do return; end
	end
	pUser:NpcSay(17605, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17610 then
	pUser:SelectMsg(17610, 17611, 17611, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17611 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	if pUser:CheckExistItem(392011000, 1) then
	pUser:RobItem(392011000, 1);
	pUser:GoldGain(500);
	do return; end
	end
	pUser:NpcSay(17615, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17620 then
	local state = pUser:SearchQuest(68);
	if state == 2 then
	pUser:NpcSay(17621, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(68);
	if state == 1 then
	pUser:NpcSay(17625, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SelectMsg(17623, 17626, 17626, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17624 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17625 then
	local state = pUser:SearchQuest(68);
	if state == 0 then
	pUser:GiveItem(910089000, 1);
	pUser:SaveEvent(68, 1);
	pUser:NpcSay(17625, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17626 then
	if pUser:EmptySlotCount() == 0 then
	pUser:NpcSay(35670, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(68);
	if state == 0 then
	pUser:GiveItem(910089000, 1);
	pUser:SaveEvent(68, 1);
	pUser:NpcSay(17625, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17630 then
	local state = pUser:SearchQuest(68);
	if state == 2 then
	pUser:SelectMsg(17631, 17634, 17634, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(68);
	if state == 1 then
	pUser:SelectMsg(17632, 17637, 17637, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(68);
	if state == 0 then
	pUser:NpcSay(17633, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
elseif nEventID == 17634 then
	if pUser:CheckExistItem(392012000, 1) then
	pUser:RobItem(392012000, 1);
	pUser:GoldGain(500);
	do return; end
	end
	pUser:NpcSay(17636, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17637 then
	local state = pUser:SearchQuest(68);
	if state == 1 then
	if pUser:CheckExistItem(910089000, 1) then
	pUser:RobItem(910089000, 1);
	pUser:SaveEvent(68, 2);
	pUser:ExpChange(5000);
	pUser:NpcSay(17638, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17639, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17640 then
	local state = pUser:SearchQuest(69);
	if state == 2 then
	pUser:NpcSay(17641, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 49 then
	pUser:NpcSay(17643, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SelectMsg(17644, 17645, 17651, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	local state = pUser:SearchQuest(69);
	if state == 1 then
	pUser:SelectMsg(17646, 17647, 17647, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17647 then
	local state = pUser:SearchQuest(69);
	if state == 1 then
	if pUser:CheckExistItem(910090000, 1) then
	pUser:RobItem(910090000, 1);
	pUser:ExpChange(10000000);
	pUser:SaveEvent(69, 2);
	pUser:NpcSay(17648, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17649, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17651 then
	local state = pUser:SearchQuest(69);
	if state == 0 then
	pUser:SaveEvent(69, 1);
	pUser:NpcSay(17651, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17660 then
	local state = pUser:SearchQuest(70);
	if state == 2 then
	pUser:NpcSay(17661, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	local state = pUser:SearchQuest(70);
	if state == 1 then
	pUser:SelectMsg(17662, 17664, 17664, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
	local state = pUser:SearchQuest(70);
	if state == 0 then
	local lvl = pUser:GetLevel();
	if lvl >= 0 and lvl <= 49 then
	pUser:NpcSay(17643, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SelectMsg(17668, 17669, 17669, 35664, 17023, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17664 then
	local state = pUser:SearchQuest(70);
	if state == 1 then
	if pUser:CheckExistItem(379104000, 1) then
	pUser:RobItem(379104000, 1);
	pUser:ExpChange(10000000);
	pUser:SaveEvent(70, 2);
	pUser:NpcSay(17665, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	end
	pUser:NpcSay(17666, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 17669 then
	local state = pUser:SearchQuest(70);
	if state == 0 then
	pUser:SaveEvent(70, 1);
	pUser:NpcSay(17666, -1, -1, -1, -1, -1, -1, -1);
	end
elseif nEventID == 17681 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NATION'.");
	if false then -- unknown logic command (CHECK_NATION)
	pUser:NpcSay(17682, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_MIDDLE_STATUE_NOCAPTURE'.");
	if false then -- unknown logic command (CHECK_MIDDLE_STATUE_NOCAPTURE)
	pUser:NpcSay(17684, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SelectMsg(17685, 17686, 17686, 17687, 17687, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 17686 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_MIDDLE_STATUE_NOCAPTURE'.");
	if false then -- unknown logic command (CHECK_MIDDLE_STATUE_NOCAPTURE)
	pUser:NpcSay(17684, -1, -1, -1, -1, -1, -1, -1);
	do return; end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_MIDDLE_STATUE_CAPTURE'.");
	if false then -- unknown logic command (CHECK_MIDDLE_STATUE_CAPTURE)
	pUser:SendDebugString("Unknown EXEC command 'MOVE_MIDDLE_STATUE'."); -- unknown execute command (MOVE_MIDDLE_STATUE)
	do return; end
	do return; end
	end
elseif nEventID == 17687 then
	do return; end
elseif nEventID == 22001 then
	pUser:SelectMsg(51000, 50007, 22010, 50006, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 22010 then
	local lvl = pUser:GetLevel();
	if lvl >= 30 and lvl <= 59 then
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_TOTAL'.");
	if false then -- unknown logic command (CHECK_SKILL_TOTAL)
	pUser:SendDebugString("Unknown EXEC command 'ZONE_CHANGE'."); -- unknown execute command (ZONE_CHANGE)
	do return; end
	end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_TOTAL'.");
	if false then -- unknown logic command (CHECK_SKILL_TOTAL)
	pUser:SendDebugString("Unknown EXEC command 'ZONE_CHANGE'."); -- unknown execute command (ZONE_CHANGE)
	do return; end
	end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_TOTAL'.");
	if false then -- unknown logic command (CHECK_SKILL_TOTAL)
	pUser:SendDebugString("Unknown EXEC command 'ZONE_CHANGE'."); -- unknown execute command (ZONE_CHANGE)
	do return; end
	end
	end
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_NOCLASS'.");
	if false then -- unknown logic command (CHECK_NOCLASS)
	pUser:SendDebugString("Unknown LOGIC command 'CHECK_SKILL_TOTAL'.");
	if false then -- unknown logic command (CHECK_SKILL_TOTAL)
	pUser:SendDebugString("Unknown EXEC command 'ZONE_CHANGE'."); -- unknown execute command (ZONE_CHANGE)
	do return; end
	end
	end
	end
elseif nEventID == 35615 then
	pUser:SelectMsg(35594, 35595, 35616, 35596, 35617, 35597, 35618, 35598, 35619, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 35616 then
	pUser:NpcSay(35595, 35596, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 35617 then
	pUser:NpcSay(35598, 35597, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 35618 then
	pUser:SelectMsg(35708, 35572, 35620, 35573, 35621, 35574, 35622, 35568, 35615, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
elseif nEventID == 35619 then
	pUser:NpcSay(35606, 35607, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 35620 then
	pUser:NpcSay(35599, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 35621 then
	pUser:NpcSay(35600, -1, -1, -1, -1, -1, -1, -1);
	do return; end
elseif nEventID == 35622 then
	pUser:NpcSay(35601, 35602, 35603, 35604, 35605, -1, -1, -1);
	do return; end
elseif nEventID == 35623 then
	pUser:SendDebugString("Unknown EXEC command 'REQUEST_PERSONAL_RANK_REWARD'."); -- unknown execute command (REQUEST_PERSONAL_RANK_REWARD)
	do return; end
elseif nEventID == 35664 then
	pUser:NpcSay(35643, -1, -1, -1, -1, -1, -1, -1);
	do return; end
else
	pUser:SendDebugString("Unprocessed event id ("..nEventID..")");
end
