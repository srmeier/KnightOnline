/*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Global.h"
#include "LOGIC_ELSE.h"

//-----------------------------------------------------------------------------
void LOGIC_ELSE::Parse_and(char* pBuf) {
	int index = 0, i = 0;
	char temp[1024];

	index += ParseSpace(temp, pBuf+index);
	memcpy(m_LogicCmd, temp, strlen(temp) + 1);

	if(!strcmp(temp, "CHECK_LV")) {
		m_LogicElse = LOGIC_CHECK_LEVEL;

		index += ParseSpace(temp, pBuf+index); m_LogicElseInt[i++] = atoi(temp); // minimum level
		index += ParseSpace(temp, pBuf+index); m_LogicElseInt[i++] = atoi(temp); // maximum level

	} else if(!strcmp(temp, "CHECK_EXIST_EVENT")) {
		m_LogicElse = LOGIC_EXIST_COM_EVENT;

		index += ParseSpace(temp, pBuf+index); m_LogicElseInt[i++] = atoi(temp); // event number
		index += ParseSpace(temp, pBuf+index); m_LogicElseInt[i++] = atoi(temp); // state (is the event at this state?)

	} else if (!strcmp(temp, "HOWMUCH_ITEM")) {
		m_LogicElse = LOGIC_HOWMUCH_ITEM;

		index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // item number
		index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // minimum amount
		index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // maximum amount

	} else if (!strcmp(temp, "CHECK_PROMOTION_ELIGIBLE")) {
		m_LogicElse = LOGIC_CHECK_PROMOTION_ELIGIBLE;

		// TODO: implement

	} else if(!strcmp(temp, "CHECK_CLASS")) {
		m_LogicElse = LOGIC_CHECK_CLASS;

		index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // class 1
		
		int old_index = index;
		index += ParseSpace(temp, pBuf + index);

		if (index != old_index) {
			m_LogicElseInt[i++] = atoi(temp); // class 2
			index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // class 3
			index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // class 4
			index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // class 5
			index += ParseSpace(temp, pBuf + index); m_LogicElseInt[i++] = atoi(temp); // class 6
		} else {
			m_LogicElseInt[i++] = -1;
			m_LogicElseInt[i++] = -1; m_LogicElseInt[i++] = -1;
			m_LogicElseInt[i++] = -1; m_LogicElseInt[i++] = -1;
		}

	} else {
		m_LogicElse = LOGIC_UNKNOWN;
		printf("Unknown logic command: %s\n", temp);
		//system("pause");
		//exit(-1);
	}

	m_bAnd = true;
}
