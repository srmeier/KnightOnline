#ifndef __GLOBAL_H_
#define __GLOBAL_H_

//-----------------------------------------------------------------------------
int ParseSpace(char* tBuf, char* sBuf);

#endif
